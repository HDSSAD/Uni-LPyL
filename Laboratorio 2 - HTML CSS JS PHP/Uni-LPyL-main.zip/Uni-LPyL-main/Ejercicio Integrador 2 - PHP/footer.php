<div id="div-emptySpace"></div>
<footer>
    <p>Alumno Díaz Sebastián Alberto</p>
</footer>