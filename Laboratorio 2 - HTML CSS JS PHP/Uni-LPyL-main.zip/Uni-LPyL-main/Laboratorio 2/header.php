<header>
<h1>Clinica</h1>
</header>